function Parse-Bulletin {

	param (
        [Parameter(Mandatory = $True)]
		[string]$BulletinCSV,
        [Parameter(Mandatory = $True)]
		[string]$QFE,
        [Parameter(Mandatory = $True)]
		[string]$OSVersion
	)

	# Some basic checks on input parameters
	if (!$(Test-Path $BulletinCSV)) {
		echo "Microsoft Security Bulletin CSV file path not valid!"
		return
	}
	if (!$(Test-Path $QFE)) {
		echo "Wmic qfe file path not valid!"
		return
	}
	$MSPatchList = Import-Csv $BulletinCSV |Where-Object {$_."Affected Product" -eq $OSVersion}
	if (!$MSPatchList) {
		echo "No patches found for supplied OS version!"
		return
	}
	
	
	# Get unique KBs and store them in HashSet
	$KBHashSet = New-Object System.Collections.Generic.HashSet[int]
	$MSPatchList | Select "Component KB" | Foreach {$KBHashSet.add($_."Component KB") | Out-Null}
	
	# Get installed KBs
	$InstalledKBs = (Select-String -Path $QFE -Pattern "KB\d+").Matches.Value.Replace("KB","")
	
	function Find-Unpatched {
		param ([int]$CurrentKB)
		
		if ($KBHashSet.Contains($CurrentKB)){
			$KBHashSet.Remove($CurrentKB) |Out-Null
		}
		
		$SupersedesKB = (($MSPatchList | Where-Object {$_."Component KB" -eq $CurrentKB}).Supersedes) | ?{$_}
		if ($SupersedesKB -ne $null){
			$SupersedesKB.trim()
			(([regex]'(?<=\[).+?(?=\])').Matches($SupersedesKB).Value).Split(";") | foreach {Find-Unpatched($_)}
		}
	}
	
	echo "Cross-Referencing patch lists .."
	#for each of the installedKBs remove it and the superseded from unpatchedKBs
	$InstalledKBs | foreach{Find-Unpatched($_)}
	
	$Array = @()
	foreach ($Patch in $KBHashSet) {
		$Array += $MSPatchList | Where-Object{$_."Component KB" -eq $Patch} |Select "Bulletin*ID", "Component KB", "Impact", "Severity"
	}

	$Array | Sort-Object "Bulletin*ID" |ft
}